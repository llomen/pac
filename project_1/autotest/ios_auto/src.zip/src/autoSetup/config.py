platform = 'iPhone'

suitepath = '/Users/klyg/Downloads/iphone_2005'


reportdir = '/Users/klyg/Downloads/report'

suiteurl = 'http://10.200.12.153/cases/UpdataTestCase'
reporturl ='http://10.200.12.153/cases/UpdataResults'

Version='iphone_1927'

#downloadApp
filepath= '~/Desktop/iphone.ipa'
bundleid = 'com.hunantv.imgotv'