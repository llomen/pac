platformVersion='12.4'
deviceName='iPhone8 Plus'
udid='3a48b102de42ae32091c8b0a8150c4c259cf9349'
platform2='iPhoneiOS'+platformVersion
appium_server='http://127.0.0.1:4724/wd/hub'
