platformVersion='13.1.2'
deviceName='iPhone8 Plus'
udid='00008020-001139E82292002E'
platform2='iPhoneiOS'+platformVersion
appium_server='http://127.0.0.1:4723/wd/hub'