#coding:utf-8
'''参数配置文件'''
""" 公共字段 """
#应用版本
appversion='imgotv-aphone-4.6.9.1'

"""pvsource 配置字段"""
pvsact='pvs'

"""pay 配置字段"""
pay_bid='2.1.1'
oppo_pix='1440*2560'

"""cdn配置字段"""
p='3'
play_cv='20151214'
down_cv='20160120'
"""广告配置字段"""
b={'4580':'','4880':''}
